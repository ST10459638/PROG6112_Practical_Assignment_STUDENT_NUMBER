/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poe1question2;

/**
 *
 * @author christopheredwardlinington
 */

//Where the public class is
public class Person {
    
    //Where the declarations are
    private String productname;
    private int productexpireydate;
    private String dangerlevel;

    //WHere the declarations are initilised
    public Person(String name, int age, String email) {
        this.productname = productname;
        this.productexpireydate = productexpireydate;
        this.dangerlevel = dangerlevel;
    }

    // Where the Getters and Setters are
    public String getproductname() { return productname; }
    public void setproductname(String productname) { this.productname = productname; }

    public int getproductexpireydate() { return productexpireydate; }
    public void setproductexpireydate(int productexpireydate) { this.productexpireydate = productexpireydate; }

    public String getdangerlevel() { return dangerlevel; }
    public void setdangerlevel(String danger) { this.dangerlevel = dangerlevel; }
}


/** 
 * This class was generated based on user input using the OpenAI ChatGPT model.
 * 
 * Reference:
 * OpenAI.(2024).*ChatGPT:Language Model*[Software].
 * Available at:
 * https://chatgpt.com
 * [Accessed 2 Sep. 2024]
 */
