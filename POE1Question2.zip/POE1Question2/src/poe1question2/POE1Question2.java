/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poe1question2;
    import java.util.Scanner;
/**
 *
 * @author christopheredwardlinington
 */



    /**
     * @param args the command line arguments
     */





public class POE1Question2 {

    // Where main method is
    public static void main(String[] args) {
        // An example of usage
        try (Scanner scanner = new Scanner(System.in)) {
            // An example of usage
            
            // Where details are placed in
            System.out.println("Enter product details:");
            
            // Product Name input
            System.out.print("Product Name: ");
            String productname = scanner.nextLine();
            
            // Expirery Date input
            System.out.print("Expirery Date: ");
            int productexpirerydate = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            
            //Danger Level Input
            System.out.print("Danger Level: ");
            String dangerlevel = scanner.nextLine();
            
            //Product Sale Input 
            System.out.print("Product Sale Number: ");
            String productSN = scanner.nextLine();
            
            //Product Origin Input
            System.out.print("Product Origin: ");
            String origin = scanner.nextLine();
            
            //WHere student details are gathered
            Student stud = new Student(productname, productexpirerydate, dangerlevel,productSN, origin);
            System.out.println("Student details:");
            System.out.println(stud.toString());
        }
    }

    public static Student createStudent(String productName, int productExpiryDate, String dangerLevel, String productSN, String origin) {
        throw new UnsupportedOperationException("Currently Lacks Support."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}


/** 
 * This class was generated based on user input using the OpenAI ChatGPT model.
 * 
 * Reference:
 * OpenAI.(2024).*ChatGPT:Language Model*[Software].
 * Available at:
 * https://chatgpt.com
 * [Accessed 2 Sep. 2024]
 */


    
     




    
   

    

