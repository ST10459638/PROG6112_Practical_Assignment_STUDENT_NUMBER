package poe1question2;




/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author christopheredwardlinington
 */

// Where the public class is
public class Student extends Person {
    private String productSN;
    private String origin;

    public Student(String productname, int productexpirerydate, String danger, String productSN, String origin) {
        super(productname, productexpirerydate, danger);
        this.productSN = productSN;
        this.origin = origin;
    }

    // Where the Getters and Setters that are additional are
    public String getproductsalesnumber() { return productSN; }
    public void setproductsalesnumber(String productsn) { this.productSN = productsn; }

    public String getorigin() { return origin; }
    public void setorigin(String origin) { this.origin = origin; }

    // How the toString is overrode in order for student details to be printed
    @Override
    public String toString() {
        return "Salesnumber: " + productSN + ", Product Name: " + getproductname() + ", Expirery Date: " + getproductexpireydate() +
                ", Danger Level: " + getdangerlevel() + ", Origin: " + origin;
    }
}


/** 
 * This class was generated based on user input using the OpenAI ChatGPT model.
 * 
 * Reference:
 * OpenAI.(2024).*ChatGPT:Language Model*[Software].
 * Available at:
 * https://chatgpt.com
 * [Accessed 2 Sep. 2024]
 */

    

