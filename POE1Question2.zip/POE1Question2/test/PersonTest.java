/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author christopheredwardlinington
 */

import poe1question2.Person;


public class PersonTest {

  
    void testPersonCreation() {
        // Where products are Arranged
        String productName = "Product A";
        int productExpiryDate = 20250625;
        String dangerLevel = "Low";
       

        // Where products Acted
        Person newentry = new Person(productName, productExpiryDate, dangerLevel);

        // Where products are Asserted
        assertEquals(productName, newentry.getproductname());
        assertEquals(productExpiryDate, newentry.getproductexpireydate());
        assertEquals(dangerLevel, newentry.getdangerlevel());
    }


    void testPersonSettersAndGetters() {
        // Where products are Arranged
        Person newentry = new Person("Product B", 20220416, "Medium");

        // Where products Acted
        newentry.setproductname("Product C");
        newentry.setproductexpireydate(20210403);
        newentry.setdangerlevel("Low");

        // Where products are Asserted
        assertEquals("Product C", newentry.getproductname());
        assertEquals(20210403, newentry.getproductexpireydate());
        assertEquals("Low", newentry.getdangerlevel());
    }

    private void assertEquals(String productName, String productname) {
        throw new UnsupportedOperationException("Currently lacks support."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertEquals(int productExpiryDate, int productexpireydate) {
        throw new UnsupportedOperationException("Currently lacks support."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}


/** 
 * This class was generated based on user input using the OpenAI ChatGPT model.
 * 
 * Reference:
 * OpenAI.(2024).*ChatGPT:Language Model*[Software].
 * Available at:
 * https://chatgpt.com
 * [Accessed 2 Sep. 2024]
 */
