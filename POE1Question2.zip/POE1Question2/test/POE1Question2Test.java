/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author christopheredwardlinington
 */

import poe1question2.POE1Question2;
import poe1question2.Student;


    


class POE1Question2Test {

    void testStudentCreation() {
        // Where products are arranged 
        String productName = "Product A";
        int productExpiryDate = 20250625;
        String dangerLevel = "Low";
        String productSN = "SN456123";
        String origin = "Japan";

        // Where products are acted
        Student student = POE1Question2.createStudent(productName, productExpiryDate, dangerLevel, productSN, origin);

        // Where products are Asserted
        assertEquals(productName, student.getproductname());
        assertEquals(productExpiryDate, student.getproductexpireydate());
        assertEquals(dangerLevel, student.getdangerlevel());
        assertEquals(productSN, student.getproductsalesnumber());
        assertEquals(origin, student.getorigin());
    }

    private void assertEquals(String productName, String productname) {
        throw new UnsupportedOperationException("Currently lacks support."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertEquals(int productExpiryDate, int productexpireydate) {
        throw new UnsupportedOperationException("Currently lacks support."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}


/** 
 * This class was generated based on user input using the OpenAI ChatGPT model.
 * 
 * Reference:
 * OpenAI.(2024).*ChatGPT:Language Model*[Software].
 * Available at:
 * https://chatgpt.com
 * [Accessed 2 Sep. 2024]
 */
