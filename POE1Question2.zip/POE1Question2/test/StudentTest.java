/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author christopheredwardlinington
 */
import poe1question2.Student;

public class StudentTest {

    
    void testStudentCreation() {
        // Where products are Arranged
        String productName = "Product A";
        int productExpiryDate = 20250625;
        String dangerLevel = "Low";
        String productSN = "SN456123";
        String origin = "Japan";

        // Where produtcs are Acted
        Student stud = new Student(productName, productExpiryDate, dangerLevel, productSN, origin);

        // Where products are Asserted
        assertEquals(productName, stud.getproductname());
        assertEquals(productExpiryDate, stud.getproductexpireydate());
        assertEquals(dangerLevel, stud.getdangerlevel());
        assertEquals(productSN, stud.getproductsalesnumber());
        assertEquals(origin, stud.getorigin());
    }

    
    void testStudentSettersAndGetters() {
        // Where products are Arranged
        Student stud = new Student("Product D", 20190201, "Mild", "SN8865044", "France");

         // Where produtcs are Acted
        stud.setproductsalesnumber("SN2245698");
        stud.setorigin("Germany");

        // Where products are Asserted
        assertEquals("SN2245698", stud.getproductsalesnumber());
        assertEquals("Germany", stud.getorigin());
    }

   
    void testStudentToString() {
        // Where products are Arranged
        String productName = "Product A";
        int productExpiryDate = 20250625;
        String dangerLevel = "Low";
        String productSN = "SN456123";
        String origin = "Japan";

        // Where produtcs are Acted
        Student student = new Student(productName, productExpiryDate, dangerLevel, productSN, origin);
        String expectedToString = "Salesnumber: SN456123, Product Name: Product A, Expirery Date: 20250625, Danger Level: Low, Origin: Japan";

        // Where products are Asserted
        assertEquals(expectedToString, student.toString());
    }

    private void assertEquals(String productName, String productname) {
        throw new UnsupportedOperationException("Currently Lacks support."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertEquals(int productExpiryDate, int productexpireydate) {
        throw new UnsupportedOperationException("Currently lacks support."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}


/** 
 * This class was generated based on user input using the OpenAI ChatGPT model.
 * 
 * Reference:
 * OpenAI.(2024).*ChatGPT:Language Model*[Software].
 * Available at:
 * https://chatgpt.com
 * [Accessed 2 Sep. 2024]
 */
