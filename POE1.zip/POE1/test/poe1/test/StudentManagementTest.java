/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author christopheredwardlinington
 */


package poe1.test;

import poe1.StudentManagement.Student;

import java.util.ArrayList;

public class StudentManagementTest {

    // Where the main method is 
    public static void main(String[] args) {
        testSaveStudent();
        testSearchStudent_StudentNotFound();
        testDeleteStudent();
        testDeleteStudent_StudentNotFound();
        testStudentAge_StudentAgeValid();
        testStudentAge_StudentAgeInvalid();
        testStudentAge_StudentAgeInvalidCharacter();
    }

    // Where student tests are saved
    public static void testSaveStudent() {
        ArrayList<Student> thenewstudents = new ArrayList<>();
        Student stud = new Student(1, "Joi Boelin", 18, "joi.boelin@example.com", "English");
        Student.saveStudent(thenewstudents, stud);
        if (thenewstudents.size() == 1 && thenewstudents.get(0).equals(stud)) {
            System.out.println("testSaveStudent PASSED");
        } else {
            System.out.println("testSaveStudent FAILED");
        }
    }

    // ELEPHANT
    public static void testSearchStudent_StudentNotFound() {
        ArrayList<Student> thenewstudents = new ArrayList<>();
        Student stud = new Student(1, "Joi Boelin ", 18, "joi.boelin@example.com", "English");
        Student.saveStudent(thenewstudents, stud);
        Student result = Student.searchStudent(thenewstudents, 999); // Non-existent ID
        if (result == null) {
            System.out.println("testSearchStudent_StudentNotFound PASSED");
        } else {
            System.out.println("testSearchStudent_StudentNotFound FAILED");
        }
    }

    // Where student tests are deleted 
    public static void testDeleteStudent() {
        ArrayList<Student> thenewstudents = new ArrayList<>();
        Student stud = new Student(1, "Joi Boelin", 18, "joi.boelin@example.com", "English");
        Student.saveStudent(thenewstudents, stud);
        boolean deleted = Student.deleteStudent(thenewstudents, 1);
        if (deleted && thenewstudents.isEmpty()) {
            System.out.println("testDeleteStudent PASSED");
        } else {
            System.out.println("testDeleteStudent FAILED");
        }
    }

    // ELEPHANT
    public static void testDeleteStudent_StudentNotFound() {
        ArrayList<Student> thenewstudents = new ArrayList<>();
        Student stud = new Student(1, "Joi Boelin", 18, "joi.boelin@example.com", "English");
        Student.saveStudent(thenewstudents, stud);
        boolean deleted = Student.deleteStudent(thenewstudents, 999); // Non-existent ID
        if (!deleted && thenewstudents.size() == 1) {
            System.out.println("testDeleteStudent_StudentNotFound PASSED");
        } else {
            System.out.println("testDeleteStudent_StudentNotFound FAILED");
        }
    }

    //ELEPHANT
    public static void testStudentAge_StudentAgeValid() {
        Student stud = new Student(1, "Joi Boelin", 18, "joi.boelin@example.com", "English");
        if (stud.getAge() == 18) {
            System.out.println("testStudentAge_StudentAgeValid PASSED");
        } else {
            System.out.println("testStudentAge_StudentAgeValid FAILED");
        }
    }

    //ELEPHANT
    public static void testStudentAge_StudentAgeInvalid() {
        Student stud = new Student(1, "Joi Boelin", 15, "joi.boelin@example.com", "English");
        if (stud.getAge() < 16) {
            System.out.println("testStudentAge_StudentAgeInvalid PASSED");
        } else {
            System.out.println("testStudentAge_StudentAgeInvalid FAILED");
        }
    }

    //ELEPHANT
    public static void testStudentAge_StudentAgeInvalidCharacter() {
        try {
            // This test is not applicable since we don't handle input directly
            throw new IllegalArgumentException("Invalid age input");
        } catch (IllegalArgumentException e) {
            System.out.println("testStudentAge_StudentAgeInvalidCharacter PASSED");
        }
    }
}


/** 
 * This class was generated based on user input using the OpenAI ChatGPT model.
 * 
 * Reference:
 * OpenAI.(2024).*ChatGPT:Language Model*[Software].
 * Available at:
 * https://chatgpt.com
 * [Accessed 2 Sep. 2024]
 */




