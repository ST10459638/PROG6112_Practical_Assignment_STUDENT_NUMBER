/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poe1;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

// Where the Main Class is
public class StudentManagement {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Student> students = new ArrayList<>();

        while (true) {
            // Where the Display Menu is
            System.out.println("STUDENT MANAGEMENT APPLICATION");
            System.out.println("Please select one of the following menu items:");
            System.out.println("(1) Capture a new student.");
            System.out.println("(2) Search for a student.");
            System.out.println("(3) Delete a student.");
            System.out.println("(4) Print student report.");
            System.out.println("(5) Exit Application.");

            int choice = -1;
            try {
                choice = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input! Please enter a number between 1 and 5.");
                scanner.nextLine(); // Where invalid input is cleared
                continue; // Where the loop restarts
            }

            scanner.nextLine(); // Where the newline is consumed

            switch (choice) {
                case 1:
                    // Where new students are captured
                    System.out.println("Enter Student ID:");
                    int id = 0;
                    try {
                        id = scanner.nextInt();
                    } catch (InputMismatchException e) {
                        System.out.println("Invalid input! Student ID must be a number.");
                        scanner.nextLine(); // Where invalid input is cleared
                        continue; // Where the loop restarts
                    }
                    scanner.nextLine(); // Where the newline is consumed

                    System.out.println("Enter Student Name:");
                    String name = scanner.nextLine();

                    int age = 0;
                    while (true) {
                        System.out.println("Enter Student Age:");
                        try {
                            age = scanner.nextInt();
                            scanner.nextLine(); // Where the newline is consumed
                            if (age >= 16) {
                                break;
                            } else {
                                System.out.println("You have entered an incorrect student age!!! Please re-enter the student age >>");
                            }
                        } catch (InputMismatchException e) {
                            System.out.println("You have entered an incorrect student age!!! Please re-enter the student age >>");
                            scanner.nextLine(); // Where invalid input is cleared
                        }
                    }

                    System.out.println("Enter Student Email:");
                    String email = scanner.nextLine();

                    System.out.println("Enter Student Course:");
                    String course = scanner.nextLine();

                    Student student = new Student(id, name, age, email, course);
                    Student.saveStudent(students, student);
                    break;

                case 2:
                    // Where students are searched for
                    System.out.println("Enter the student id to search:");
                    int searchId = 0;
                    try {
                        searchId = scanner.nextInt();
                    } catch (InputMismatchException e) {
                        System.out.println("Invalid input! Student ID must be a number.");
                        scanner.nextLine(); // Where invalid input is cleared
                        continue; // Where the loop restarts
                    }
                    scanner.nextLine(); // Where the newline is consumed
                    Student foundStudent = Student.searchStudent(students, searchId);
                    if (foundStudent != null) {
                        System.out.println("STUDENT ID: " + foundStudent.getStId());
                        System.out.println("STUDENT NAME: " + foundStudent.getFullName());
                        System.out.println("STUDENT AGE: " + foundStudent.getAge());
                        System.out.println("STUDENT EMAIL: " + foundStudent.getEmailAddress());
                        System.out.println("STUDENT COURSE: " + foundStudent.getCourseofStudy());
                    } else {
                        System.out.println("Student with Student Id: " + searchId + " was not found!");
                    }
                    break;

                case 3:
                    // Where the student is deleted
                    System.out.println("Enter the student id to delete:");
                    int deleteId = 0;
                    try {
                        deleteId = scanner.nextInt();
                    } catch (InputMismatchException e) {
                        System.out.println("Invalid input! Student ID must be a number.");
                        scanner.nextLine(); // WHere invalid input is cleared
                        continue; // WHere the loop restarts 
                    }
                    scanner.nextLine(); // Where the newline is consumed
                    System.out.println("Are you sure you want to delete this student? (yes/no)");
                    String confirm = scanner.nextLine();
                    if (confirm.equalsIgnoreCase("yes")) {
                        boolean deleted = Student.deleteStudent(students, deleteId);
                        if (deleted) {
                            System.out.println("Student with Student Id: " + deleteId + " was successfully deleted.");
                        } else {
                            System.out.println("Student with Student Id: " + deleteId + " was not found!");
                        }
                    } else {
                        System.out.println("Student deletion cancelled.");
                    }
                    break;

                case 4:
                    // Where student reports are printed
                    Student.studentReport(students);
                    break;

                case 5:
                    // WHere the application is exited
                    Student.exitStudentApplication();
                    break;

                default:
                    System.out.println("Invalid choice. Please select a valid menu item.");
                    break;
            }

            System.out.println("Enter (1) to launch menu or any other key to exit");
            String restartChoice = scanner.nextLine();
            if (!restartChoice.equals("1")) {
                Student.exitStudentApplication();
            }
        }
    }

    

// Where the Student class is
public static class Student {
    private final int StID;
    private String FullName;
    private int Age;
    private String EmailAddress;
    private String CourseofStudy;

    // Where the Constructor is
    public Student(int StudentID, String NameofStudent, int AgeofStudent, String EmailofStudent, String CourseofStudent) {
        this.StID = StudentID;
        this.FullName = NameofStudent;
        this.Age = AgeofStudent;
        this.EmailAddress = EmailofStudent;
        this.CourseofStudy = CourseofStudent;
    }

    // Where the Getters are
    public int getStId() {
        return StID;
    }

    public String getFullName() {
        return FullName;
    }

    public int getAge() {
        return Age;
    }

    public String getEmailAddress() {
        return EmailAddress;
    }

    public String getCourseofStudy() {
        return CourseofStudy;
    }

    // Where Setters are
    public void setFullName(String NameofStudent) {
        this.FullName = NameofStudent;
    }

    public void setAge(int AgeofStudent) {
        this.Age = AgeofStudent;
    }

    public void setEmailAddress(String EmailofStudent) {
        this.EmailAddress = EmailofStudent;
    }

    public void setCourseofStudy(String CourseofStudent) {
        this.CourseofStudy = CourseofStudent;
    }

    // WHere student methods are saved
    public static void saveStudent(ArrayList<Student> students, Student student) {
        students.add(student);
        System.out.println("Student details successfully saved.");
    }

    // Where student methods are searched for 
    public static Student searchStudent(ArrayList<Student> students, int StudentID) {
        for (Student student : students) {
            if (student.getStId() == StudentID) {
                return student;
            }
        }
        return null;
    }

    // Where student methods are deleted 
    public static boolean deleteStudent(ArrayList<Student> students, int StudentID) {
        Student student = searchStudent(students, StudentID);
        if (student != null) {
            students.remove(student);
            System.out.println("Student with ID " + StudentID + " has been removed.");
            return true;
        }
        System.out.println("Student with ID " + StudentID + " not found.");
        return false;
    }

    // Where student report are printed
    public static void studentReport(ArrayList<Student> students) {
        if (students.isEmpty()) {
            System.out.println("No students found.");
        } else {
            int count = 1;
            for (Student student : students) {
                System.out.println("STUDENT " + count);
                System.out.println("STUDENT ID: " + student.getStId());
                System.out.println("STUDENT NAME: " + student.getFullName());
                System.out.println("STUDENT AGE: " + student.getAge());
                System.out.println("STUDENT EMAIL: " + student.getEmailAddress());
                System.out.println("STUDENT COURSE: " + student.getCourseofStudy());
                System.out.println();
                count++;
            }
        }
    }

    // where the exit application is
    public static void exitStudentApplication() {
        System.out.println("Exiting the application...");
        System.exit(0);
    }
}
}

/** 
 * This class was generated based on user input using the OpenAI ChatGPT model.
 * 
 * Reference:
 * OpenAI.(2024).*ChatGPT:Language Model*[Software].
 * Available at:
 * https://chatgpt.com
 * [Accessed 2 Sep. 2024]
 */
